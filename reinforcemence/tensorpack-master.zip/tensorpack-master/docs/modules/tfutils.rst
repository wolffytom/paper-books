tensorpack.tfutils package
==========================

tensorpack.tfutils.collection module
------------------------------------

.. automodule:: tensorpack.tfutils.collection
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.distributions module
---------------------------------------

.. automodule:: tensorpack.tfutils.distributions
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.gradproc module
------------------------------------

.. automodule:: tensorpack.tfutils.gradproc
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.model_utils module
------------------------------------

.. automodule:: tensorpack.tfutils.model_utils
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.scope_utils module
------------------------------------

.. automodule:: tensorpack.tfutils.scope_utils
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.optimizer module
------------------------------------

.. automodule:: tensorpack.tfutils.optimizer
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.sesscreate module
------------------------------------

.. automodule:: tensorpack.tfutils.sesscreate
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.summary module
---------------------------------

.. automodule:: tensorpack.tfutils.summary
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.symbolic_functions module
--------------------------------------------

.. automodule:: tensorpack.tfutils.symbolic_functions
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.varmanip module
----------------------------------

.. automodule:: tensorpack.tfutils.varmanip
    :members:
    :undoc-members:
    :show-inheritance:

tensorpack.tfutils.varreplace module
------------------------------------

.. automodule:: tensorpack.tfutils.varreplace
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: tensorpack.tfutils
    :members:
    :undoc-members:
    :show-inheritance:

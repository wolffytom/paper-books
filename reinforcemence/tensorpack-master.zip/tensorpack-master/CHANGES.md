
## Breaking API changes.

tensorpack is still in early development, and API changes can happen.
The backward compatibilty will be __preserved for several months__, with a deprecation warning,
so you won't need to look at here very often.

Here are a list of things that were changed, starting from an early version.
TensorFlow itself also changed APIs before 1.0 and those are not listed here.

+ [2017/05/06](https://github.com/ppwwyyxx/tensorpack/commit/0774ec66e66075486f6a36aba63cc2a151b9fec8).
	`replace_get_variable` was deprecated in favor of the official `custom_getter` interface.
	`{freeze,remap}_get_variable` was renamed to `{freeze,remap}_variables`.
+ [2017/04/09](https://github.com/ppwwyyxx/tensorpack/commit/5beab907895aec36bdcaed62e25b976aad7979b8).
	`ParamRestore` was renamed to `DictRestore`.
+ [2017/03/16](https://github.com/ppwwyyxx/tensorpack/commit/ccae46f4a3ca89dc3df901a338eef8447d19a730).
	`session_config` option in `TrainConfig` and `PredictConfig` is deprecated.
	Use `session_creator` to define how to create session instead.
+ 2017/02/20. The interface of step callbacks are changed to be the same as `tf.train.SessionRunHook`.
	If you haven't written any custom step callbacks, there is nothing to do. Otherwise please refer
	to the [existing callbacks](https://github.com/ppwwyyxx/tensorpack/blob/master/tensorpack/callbacks/steps.py).
+ [2017/02/12](https://github.com/ppwwyyxx/tensorpack/commit/d1041a77a9c59d8c9abf64f389f3b605d65b483e).
	`TrainConfig(optimizer=)` was deprecated. Now optimizer is set in `ModelDesc`. And gradient processors become part of an optimizer.
* [2017/02/11](https://github.com/ppwwyyxx/tensorpack/commit/5b29bda9f17d7b587259e13963c4c8093e8387f8).
	`_get_input_vars()` in `ModelDesc` was renamed to `_get_inputs`. `InputVar` was renamed to `InputDesc`.
* [2017/01/27](https://github.com/ppwwyyxx/tensorpack/commit/a9dd0b8ec34209ab86a92875589dbbc4716e73ef).
	`TrainConfig(step_per_epoch)` was renamed to `steps_per_epoch`.
* [2017/01/25](https://github.com/ppwwyyxx/tensorpack/commit/2df3dcf401a99fe61c699ad719e95528872d3abe).
	Argument order of `models.ConcatWith` is changed to follow the API change in TensorFlow upstream.
* [2017/01/25](https://github.com/ppwwyyxx/tensorpack/commit/243e957fe6d62a0cfb5728bd77fb3e005d6603e4).
	`TrainConfig(callbacks=)` now takes a list of `Callback` instances.
* [2017/01/06](https://github.com/ppwwyyxx/tensorpack/commit/bbf41d9e58053f843d0471e6d2d87ff714a79a90).
	`summary.add_moving_summary` now takes any number of positional arguments instead of a list.
* [2017/01/05](https://github.com/ppwwyyxx/tensorpack/commit/651a5aea8f9aacad7147542021dcf106fc824bc2).
	The argument `TrainConfig(dataset=)` is renamed to `TrainConfig(dataflow=)`.
* [2016/12/15](https://github.com/ppwwyyxx/tensorpack/commit/99c70935a7f72050f45891fbbcc49c4ce43aedce).
	The `predict_tower` option is in `TrainConfig` now instead of `Trainer`.
* [2016/11/10](https://github.com/ppwwyyxx/tensorpack/commit/77bcc8b1afc984a569f6ec3eda0a3c47b4e2923a).
	The `{input,output}_var_names` argument in `PredictConfig` is renamed to `{input,output}_names`.
* [2016/11/06](https://github.com/ppwwyyxx/tensorpack/commit/740e9d8ca146af5a911f68a369dd7348243a2253).
	The inferencer `ClassificationError` now expects the vector tensor returned by `prediction_incorrect` instead of the "wrong" tensor.
* [2016/10/17](https://github.com/ppwwyyxx/tensorpack/commit/6eb0bebe60d6f38bcad9ddb3e6091b0b154a09cf).
	`Conv2D` and `FullyConnect` use `tf.identity` by default instead of `tf.nn.relu`.
* [2016/09/01](https://github.com/ppwwyyxx/tensorpack/commit/fc9e45b0208ff09daf454d3bd910c540735b7f83).
	The method `_build_graph` of `ModelDesc` doesn't take `is_training` argument anymore.
	The `is_training` attribute can be obtained from tower context.
* [2016/05/15](https://github.com/ppwwyyxx/tensorpack/commit/e69034b5c9b588db9fb52295b1e63c89e8b42654).
	The method `_get_cost` of `ModelDesc` is replaced by `_build_graph`.


